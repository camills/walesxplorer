
export const colors = {
  darkBlue: '#394c5b',
  grey: '#a8aebf',
  lightGrey: '#f9f6f6',
  brokenWhite: '#f8f7f0'
};
