export const SET_MONUMENTS = 'SET_MONUMENTS';
export const SET_PHOTOS = 'SET_PHOTOS';
