export const ADD_LAYER = 'ADD_LAYER';
export const TOGGLE_LAYER = 'TOGGLE_LAYER';